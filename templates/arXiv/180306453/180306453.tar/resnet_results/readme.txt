change in two parameters
1. learning rate
lr10m4 means learning_rate = 10^-4

2. lambda
lam10e2 means lambda = 10^2
